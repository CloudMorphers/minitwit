namespace MiniTwit.Models.Api;

public class MessageInputModel
{
    public string? Content { get; set; }
}
