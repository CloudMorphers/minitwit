namespace MiniTwit.Models.Api;

public class FollowInputModel
{
    public string? Follow { get; set; }

    public string? Unfollow { get; set; }
}
